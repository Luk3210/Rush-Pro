/**
 * 
 */
/**
 * 
 */
module mapInfogen {
	requires java.desktop;
}